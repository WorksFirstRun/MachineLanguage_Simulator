#include "../Headers/Memory.h"

void Memory::Initialize(Byte c[256]) {
    for(int i = 0; i < 256; i++) {
        cells[i] = c[i];
    }
}

void Memory::Clear() {
    for(int i = 0; i < 256; i++) {
        cells[i] = Byte(0);
    }
}

void Memory::WriteAtCell(int cellIndex, Byte Value) {
    if(cellIndex >= 0 && cellIndex < 256) {
        cells[cellIndex] = Value;
    }
}

Byte Memory::GetCellAtIndex(int index) {
    if(index >= 0 && index < 256) {
        return cells[index];
    }
    return Byte(0);
}
