#include "MainProgramClasses/Headers//CPU.h"
#include "MainProgramClasses//Headers/Memory.h"
#include "SmallClasses/Headers/Byte.h"
#include <iostream>
using namespace std;


int main(){
    int t=5;
    Byte input[10];
    int j = 0;
    for(int i=0;i<t;i++){
        string in;
        cin>>in;
        string k=in.substr(0,2);
        input[j].SetByteInHex(k);
        j++;
        input[j].SetByteInHex(in.substr(2,2));
        j++;
    }
    CPU *cpu = CPU::GetInstance();
    Byte fullArray[256] = {0}; 
    for(int i = 0; i < t * 2 && i < 256; i++) {
        fullArray[i] = input[i];
    }
    cpu->GetMemory().Initialize(fullArray);
    cpu->GetControlUnit().GetProgramCounter().SetStartingAddress(0);

    cpu->RunEntireCycle();





    return 0;
}
