#ifndef MACHINELANGUAGE_SIMULATOR_MACHINE_H
#define MACHINELANGUAGE_SIMULATOR_MACHINE_H

#include "CPU.h"
#include "Memory.h"
#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

class Machine {
private:
    Memory & memory;
    

    bool isValidHexPair(const string& hexPair) const;
    void validateMemoryContent(const vector<Byte>& content) const;
    
public:
    CPU* cpu;  // Moved from private to public
    Machine(string fileName); 
    ~Machine(); 
};

extern "C" {
    __declspec(dllexport) Machine* CreateMachine(const char* fileName);
    __declspec(dllexport) void RunMachine(Machine* machine);
}

#endif //MACHINELANGUAGE_SIMULATOR_MACHINE_H
